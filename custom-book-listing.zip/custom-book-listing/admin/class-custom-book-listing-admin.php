<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://http://localhost/newplugin
 * @since      1.0.0
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/admin
 * @author     Snehi <snehipatel30@gmail.com>
 */
class Custom_Book_Listing_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Custom_Book_Listing_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Custom_Book_Listing_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/custom-book-listing-admin.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Custom_Book_Listing_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Custom_Book_Listing_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/custom-book-listing-admin.js', array('jquery'), $this->version, false);
	}

	public function custom_book_listing_register_post_type()
	{

		register_post_type('book', array(
			'labels' => array(
				'name'               => __('Books', 'textdomain'),
				'singular_name'      => __('Book', 'textdomain'),
				'add_new'            => __('Add New Book', 'textdomain'),
				'add_new_item'       => __('Add New Book', 'textdomain'),
				'edit_item'          => __('Edit Book', 'textdomain'),
				'new_item'           => __('New Book', 'textdomain'),
				'all_items'          => __('All Books', 'textdomain'),
				'view_item'          => __('View Book', 'textdomain'),
				'search_items'       => __('Search Books', 'textdomain'),
				'not_found'          => __('No books found', 'textdomain'),
				'not_found_in_trash' => __('No books found in Trash', 'textdomain'),
				'menu_name'          => __('Books', 'textdomain'),
			),
			'public'             => true,
			'has_archive'        => true,
			'rewrite'            => array('slug' => 'books'),
			'show_in_rest'       => true,
			'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'author'),
			'menu_position'      => 5,
			'menu_icon'          => 'dashicons-book',
		));
	}

	public function custom_book_add_price_range_meta_box()
	{
		add_meta_box(
			'custom_book_price_range',
			__('Price Range', 'custom-book-listing'),
			array($this, 'custom_book_price_range_meta_box_callback'),
			'book',
			'normal',
			'high'
		);

		add_meta_box(
			'book_author_name',
			'Author Name',
			array($this, 'book_author_name_callback'),
			'book',
			'normal',
			'default'
		);
	}
	public function custom_book_price_range_meta_box_callback($post)
	{
		// Retrieve existing value from post meta
		$price_range = get_post_meta($post->ID, '_book_price_range', true);

		// Output field
		echo '<label for="book_price_range">' . __('Enter price range (e.g., $10 - $30)', 'textdomain') . '</label>';
		echo '<input type="text" id="book_price_range" name="book_price_range" value="' . esc_attr($price_range) . '" style="width:100%;" />';
	}

	public function book_author_name_callback($post)
	{
		$selected_author = get_post_meta($post->ID, '_book_author_name', true);
		$users = get_users(['role__in' => ['author', 'editor', 'administrator']]); // Adjust roles as needed

		echo '<select name="book_author_name" style="width:100%;">';
		echo '<option value="">Select Author</option>';
		foreach ($users as $user) {
			$selected = selected($selected_author, $user->ID, false);
			echo "<option value='{$user->ID}' {$selected}>{$user->display_name}</option>";
		}
		echo '</select>';

		wp_nonce_field('book_author_name_nonce', 'book_author_name_nonce_field');
	}

	public function custom_book_save_price_range_meta_box_data($post_id)
	{
		// Check if our field is set
		if (array_key_exists('book_price_range', $_POST)) {
			update_post_meta(
				$post_id,
				'_book_price_range',
				sanitize_text_field($_POST['book_price_range'])
			);
		}
		if (!isset($_POST['book_author_name_nonce_field']) || !wp_verify_nonce($_POST['book_author_name_nonce_field'], 'book_author_name_nonce')) {
			return;
		}

		if (isset($_POST['book_author_name'])) {
			update_post_meta($post_id, '_book_author_name', sanitize_text_field($_POST['book_author_name']));
		}
	}
}
