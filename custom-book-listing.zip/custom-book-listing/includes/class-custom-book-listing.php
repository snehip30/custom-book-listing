<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://http://localhost/newplugin
 * @since      1.0.0
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/includes
 * @author     Snehi <snehipatel30@gmail.com>
 */
class Custom_Book_Listing
{

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Custom_Book_Listing_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct()
	{
		if (defined('CUSTOM_BOOK_LISTING_VERSION')) {
			$this->version = CUSTOM_BOOK_LISTING_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'custom-book-listing';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

		add_action('rest_api_init', array($this, 'custom_book_listing_api_endpoint'));
	}

	/**
	 * Rest Endpoint.
	 */
	public function custom_book_listing_api_endpoint()
	{
		register_rest_route('books/v1', '/list', array(
			'methods' => 'GET',
			'callback' => array($this, 'custom_books_rest_endpoint'),
			'permission_callback' => '__return_true'
		));
	}

	/**
	 * Callback function of rest route to handle received data.
	 */
	public function custom_books_rest_endpoint($data)
	{
		$params = $data->get_params();
		$meta_query = [];
		$args = [
			'post_type' => 'book',
			'posts_per_page' => isset($params['limit']) ? intval($params['limit']) : 5,
			'paged' => isset($params['page']) ? intval($params['page']) : 1,
		];

		// Author filter (custom field)
		if (!empty($params['author'])) {
			$meta_query[] = [
				'key' => '_book_author_name',
				'value' => sanitize_text_field($params['author']),
				'compare' => 'LIKE'
			];
		}

		// Price range filter
		if (!empty($params['price'])) {
			[$min, $max] = explode('-', $params['price']);
			$meta_query[] = [
				'key' => '_book_price_range',
				'value' => [(int) $min, (int) $max],
				'type' => 'NUMERIC',
				'compare' => 'BETWEEN'
			];
		}

		if ($meta_query) {
			$args['meta_query'] = $meta_query;
		}

		// Order and orderby
		if (!empty($params['orderby'])) {
			$args['orderby'] = !empty($params['orderby']) ? sanitize_text_field($params['orderby']) : 'date';
			$args['order'] = !empty($params['order']) ? strtoupper($params['order']) : 'DESC';
		}

		$query = new WP_Query($args);
		$books = [];
		if ($query->have_posts()) {
			while ($query->have_posts()) {
				$query->the_post();

				$books[] = [
					'id' => get_the_ID(),
					'title' => get_the_title(),
					'date' => get_the_date(),
					'author' => get_post_meta(get_the_ID(), '_book_author_name', true),
					'price' => get_post_meta(get_the_ID(), '_book_price_range', true),
					'link' => get_permalink()
				];
			}
		}

		wp_reset_postdata();

		return new WP_REST_Response([
			'success' => true,
			'books' => $books,
			'message' => 'It works!',
			'total' => $query->found_posts
		], 200);
	}


	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Custom_Book_Listing_Loader. Orchestrates the hooks of the plugin.
	 * - Custom_Book_Listing_i18n. Defines internationalization functionality.
	 * - Custom_Book_Listing_Admin. Defines all hooks for the admin area.
	 * - Custom_Book_Listing_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies()
	{

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-custom-book-listing-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-custom-book-listing-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-custom-book-listing-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-custom-book-listing-public.php';

		require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-custom-book-listing-public-shortcode.php';

		require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-custom-book-listing-public-ajax-function.php';

		$this->loader = new Custom_Book_Listing_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Custom_Book_Listing_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale()
	{

		$plugin_i18n = new Custom_Book_Listing_i18n();

		$this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks()
	{

		$plugin_admin = new Custom_Book_Listing_Admin($this->get_plugin_name(), $this->get_version());

		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
		$this->loader->add_action('init', $plugin_admin, 'custom_book_listing_register_post_type');
		$this->loader->add_action('add_meta_boxes', $plugin_admin, 'custom_book_add_price_range_meta_box');
		$this->loader->add_action('save_post', $plugin_admin, 'custom_book_save_price_range_meta_box_data');
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks()
	{

		$plugin_public = new Custom_Book_Listing_Public($this->get_plugin_name(), $this->get_version());
		$shortcodeObj = new Custom_Book_Listing_Public_Shortcode($this->plugin_name, $this->version);
		$ajaxObj = new Custom_Book_Listing_Public_Ajax_Function($this->plugin_name, $this->version);
		$this->loader->add_action('init', $shortcodeObj, 'register_shortcodes');
		$this->loader->add_action('init', $ajaxObj, 'register_ajax_call');
		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run()
	{
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name()
	{
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Custom_Book_Listing_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader()
	{
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version()
	{
		return $this->version;
	}
}
