<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://http://localhost/newplugin
 * @since      1.0.0
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/includes
 * @author     Snehi <snehipatel30@gmail.com>
 */
class Custom_Book_Listing_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
