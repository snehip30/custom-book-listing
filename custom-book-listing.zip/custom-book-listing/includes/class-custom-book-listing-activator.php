<?php

/**
 * Fired during plugin activation
 *
 * @link       https://http://localhost/newplugin
 * @since      1.0.0
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/includes
 * @author     Snehi <snehipatel30@gmail.com>
 */
class Custom_Book_Listing_Activator
{

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate()
	{

		//flush_rewrite_rules();
	}
}
