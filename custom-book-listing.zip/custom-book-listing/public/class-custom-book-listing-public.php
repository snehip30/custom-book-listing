<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://http://localhost/newplugin
 * @since      1.0.0
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Custom_Book_Listing
 * @subpackage Custom_Book_Listing/public
 * @author     Snehi <snehipatel30@gmail.com>
 */
class Custom_Book_Listing_Public
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Custom_Book_Listing_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Custom_Book_Listing_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/custom-book-listing-public.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Custom_Book_Listing_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Custom_Book_Listing_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/custom-book-listing-public.js', array('jquery'), $this->version, false);
		wp_localize_script($this->plugin_name, 'ajax_obj', array(
			'ajax_url' => admin_url('admin-ajax.php'),
		));
	}

	public static  function custom_book_ajax_query($filters = [])
	{
		$paged = isset($filters['paged']) ? intval($filters['paged']) : 1;

		$args = [
			'post_type' => 'book',
			'posts_per_page' => 2,
			'paged' => $paged,
		];

		$order = ($_POST['author_name'] === 'Z-A') ? 'DESC' : 'ASC';

		// Order by title
		if (!empty($filters['author_name'])) {
			$args['meta_key'] = '_book_author_name';
			$args['orderby'] = 'meta_value';
			$args['order'] = $order;
		}

		// Order by date
		if (!empty($filters['date'])) {
			$args['orderby'] = 'date';
			$args['order'] = $filters['date'] === 'newest' ? 'DESC' : 'ASC';
		}

		// Price range filter
		if (!empty($filters['price'])) {
			[$min, $max] = explode('-', $filters['price']);
			$args['meta_query'] = [
				[
					'key' => '_book_price_range',
					'value' => [$min, $max],
					'compare' => 'BETWEEN',
					'type' => 'NUMERIC'
				]
			];
		}

		// Add transient caching key
		$cache_key = 'book_filter_' . md5(json_encode($args));
		$cached = get_transient($cache_key);
		if ($cached !== false) return $cached;

		$query = new WP_Query($args);
		ob_start();
?>
		<div id="book-results">
			<?php
			if ($query->have_posts()) {
				while ($query->have_posts()) : $query->the_post();
					$post_id = get_the_ID();
			?>

					<div class="book-item">
						<h4><?php the_title(); ?></h4>
						<p><?php echo get_the_date('F j, Y'); ?></p>
						<p><?php the_author(); ?></p>
						<p>Price: <?php echo esc_html(get_post_meta($post_id, '_book_price_range', true)); ?></p>
					</div>

			<?php
				endwhile;

				// Pagination
				echo paginate_links([
					'total' => $query->max_num_pages,
					'current' => $paged,
					'format' => '?paged=%#%',
				]);
			} else {
				echo 'No books found.';
			}
			?>
		</div>
<?php
		wp_reset_postdata();

		$output = ob_get_clean();
		set_transient($cache_key, $output, 12 * HOUR_IN_SECONDS);
		return $output;
	}
}
