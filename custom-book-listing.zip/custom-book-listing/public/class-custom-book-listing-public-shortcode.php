<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://#
 * @since      1.0.0
 *
 * @package    Hotel_Booking_Reservation
 * @subpackage Hotel_Booking_Reservation/public/partials
 */

class Custom_Book_Listing_Public_Shortcode
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */

    public function __construct($plugin_name, $version)
    {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }


    public function register_shortcodes()
    {
        add_shortcode('advanced_books', array($this, 'display_advanced_books'));
    }

    /**
     * Display books shortcode.
     *
     * @since    1.0.0
     */
    public function display_advanced_books()
    {

        ob_start(); ?>
        <h2>All Books</h2>
        <p><strong>Filters</strong></p>
        Author Name
        <div id="book-filters">
            <select name="author_name" id="author_name">
                <option value="A-Z">A - Z </option>
                <option value="Z-A">Z - A</option>
            </select>
            Price Range
            <select name="price" id="price_range">
                <option value="50-100">50 - 100 </option>
                <option value="100-150">100 - 150</option>
                <option value="150-200">150 - 200</option>
            </select>
            Date
            <select name="date" id="date_range">
                <option value="newest">Newest </option>
                <option value="oldest">Oldest</option>
            </select>
        </div>
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $args = array(
            'posts_per_page' => 3,
            'paged' => $paged,
            'post_type' => 'book',
            'orderby' => 'DATE',
            'order' => 'desc'
        );
        $wp_query = new WP_Query($args);
        ?>
        <div id="book-results">
            <?php if ($wp_query->have_posts()) : ?>
                <?php while ($wp_query->have_posts()) : $wp_query->the_post();
                    $post_id = get_the_ID();
                ?>
                    <div>
                        <h4><?php the_title(); ?></h4>
                        <p><?php echo get_the_date('l F j, Y'); ?></p>
                        <p><?php the_author(); ?></p>
                        Price: <?php $price_range = get_post_meta($post_id, '_book_price_range', true);
                                echo $price_range;
                                ?>
                    </div>
                <?php endwhile;
                // Pagination
                echo paginate_links([
                    'total' => $wp_query->max_num_pages,
                    'current' => $paged,
                    'format' => '?paged=%#%',
                ]);
                ?>
            <?php else: ?>
                <?php echo "No Books found"; ?>
            <?php endif; ?>
        </div>
        <?php wp_reset_postdata(); ?>
<?php
        return ob_get_clean();
    }
}
