jQuery(document).ready(function ($) {
	function fetchBooks(paged = 1) {
		const data = {
			action: 'filter_books',
			author_name: $('#author_name').val(),
			price: $('#price_range').val(),
			date: $('#date_range').val(),
			paged: paged
		};

		$.post(ajax_obj.ajax_url, data, function (response) {
			$('#book-results').html(response);
		});
	}

	$('#book-filters select').on('change', function () {
		fetchBooks(1);
	});

	$(document).on('click', '#book-results .page-numbers', function (e) {
		e.preventDefault();
		const paged = $(this).text();
		fetchBooks(paged);
	});
});


