<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://#
 * @since      1.0.0
 *
 * @package    Hotel_Booking_Reservation
 * @subpackage Hotel_Booking_Reservation/public/partials
 */

class Custom_Book_Listing_Public_Ajax_Function
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the functions here.
     *
     * @since    1.0.0
     */
    public function register_ajax_call()
    {
        add_action('wp_ajax_filter_books', array($this, 'custom_book_filter_ajax'));
        add_action('wp_ajax_nopriv_filter_books', array($this, 'custom_book_filter_ajax'));
    }

    /**
     * Register form using ajax function
     *
     * @since    1.0.0
     */
    public function custom_book_filter_ajax()
    {
        $filters = [
            'author_name' => sanitize_text_field($_POST['author_name'] ?? ''),
            'price'       => sanitize_text_field($_POST['price'] ?? ''),
            'date'        => sanitize_text_field($_POST['date'] ?? ''),
            'paged'       => intval($_POST['paged'] ?? 1),
        ];
        echo Custom_Book_Listing_Public::custom_book_ajax_query($filters);
        wp_die();
    }
}
